#include<iostream>
using namespace std;

template<typename t>

class Node{
    public:
        t data;
        Node<t> * next;
        Node(t data){
            this->data = data;
            next = NULL;
        }
};

template<typename t>
class stack{
    Node<t> * head;
    int size;
    public: 
        stack(){
            head = NULL;
            size =0;
    }
    int getSize(){
        return size;
    }
    bool isEmpty(){
        return size ==0;
    }
    void push(t element){
        Node<t> *newNode = new Node<t>(element);
        newNode->next = head;
        head = newNode;
        size++;
    }
    t pop(){
        if(isEmpty()){
            return 0;
        }
       t ans = head->data;
       Node<t> *temp = head;
       head = head->next;
       delete temp;
       size--;
       return ans;
     }
    t top(){
        if(isEmpty()){
            return 0;
        }
        return head->data;
    }
};

int main(){
    stack<int> s;
    s.push(10);
    s.push(10);
    s.push(10);

    cout<<s.pop()<<endl;
    cout<<s.pop()<<endl;
    cout<<s.pop()<<endl;

    cout<<s.getSize()<<endl;
    return 0;
}