#include<iostream>
using namespace std;
template <typename T, typename V>

class Pair{
    private:
        T x;
        V y;
    public:
        void setX(T x){
            this->x =x;
        }
        T getX(){
            return x;
        }
        void setY(V y ){
            this->y = y;
        }
        V getY(){
            return y;
        }
};

int main(){
    Pair<Pair<int,int>,double> p;
    p.setY(12);
    Pair<int,int> p1;
    p1.setX(10);
    p1.setY(11);
    p.setX(p1);

    cout<<p.getX().getX()<<" "<<p.getX().getY()<<" "<<p.getY();

    // Pair<int, double> p;
    // p.setX(10);
    // p.setY(15.202);
    // cout<<p.getX()<<" "<<p.getY();


    // Pair<int> p;
    // p.setX(12);
    // p.setY(15);
    // cout<<p.getX()<<" "<<p.getY();
    return 0;
}