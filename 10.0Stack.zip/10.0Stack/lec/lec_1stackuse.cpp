#include<iostream>
using namespace std;
// #include "StackUsingArray.cpp"
// #include "dynamicStack.cpp"
#include "lec5_stackTemplate.cpp"
int main(){
    // Stack s(4);
    // s.push(10);
    // s.push(20);
    // s.push(30);
    // s.push(40);
    // s.push(50);

    // cout<<s.pop()<<endl;
    // cout<<s.pop()<<endl;
    // cout<<s.pop()<<endl;

    // cout<<s.top()<<endl;
    // cout<<s.isEmpty()<<endl;
    // cout<<s.size()<<endl;

    // dyStack ds;
    // ds.push(10);
    // ds.push(20);
    // ds.push(30);
    // ds.push(40);
    // ds.push(50);
    // ds.push(60);

    // cout<<ds.pop()<<endl;
    // cout<<ds.pop()<<endl;
    // cout<<ds.pop()<<endl;
    // cout<<ds.pop()<<endl;
    // cout<<ds.pop()<<endl;
    // cout<<ds.pop()<<endl;
    // cout<<ds.size()<<endl;

    // ds.push(70);
    // cout<<ds.size()<<endl;
    // cout<<ds.top()<<endl;

    TStack<int> st;
    st.push(12);
    st.push(14);
    st.push(15);
    st.push(18);

    cout<<st.pop()<<endl;
    cout<<st.pop()<<endl;
    cout<<st.pop()<<endl;
    cout<<st.pop()<<endl;

    TStack<char> ts;
    ts.push('a');
    ts.push('b');
    ts.push('c');
    ts.push('d');

    cout<<ts.pop()<<endl;
    cout<<ts.pop()<<endl;
    cout<<ts.pop()<<endl;
    cout<<ts.pop()<<endl;
    return 0;
}