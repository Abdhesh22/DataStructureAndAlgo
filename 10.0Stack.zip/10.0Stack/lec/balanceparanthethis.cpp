#include<bits/stdc++.h>
using namespace std;

bool checkbal(string s){
    stack<char> stk;
    char x;
    for (int i = 0; i <s.length(); i++)
    {
        if( s[i] == '(' || s[i] == '{' || s[i]=='['){
                stk.push(s[i]);
                continue;
        }
        switch (s[i])
        {
        case ')':
            x = stk.top();
            stk.pop();
            if (x=='{' || x==']')
            {
                return false;
            }
            break;
        case '}':
            x = stk.top();
            stk.pop();
            if (x=='(' || x=='[')
            {
                return false;
            }
            break;
        case ']':
            x = stk.top();
            stk.pop();
            if (x=='{' || x=='(')
            {
                return false;
            }
            break;
        }
    }
    return (stk.empty());
}

int main(){
    string s;
    getline(cin,s);
    if(checkbal(s)){
        cout<<"balance"<<endl;
    }else{
        cout<<"Not balance"<<endl;
    }
}