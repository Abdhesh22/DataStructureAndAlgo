#include<iostream>
#include<stack>

using namespace std;

int main(){
    stack<int> s;
    s.push(20);
    s.push(21);
    s.push(22);
    s.push(23);

    s.pop();
    
    cout<<s.top()<<endl;
    cout<<s.size()<<endl;
    cout<<s.empty()<<endl;
    return 0;
}