#include<climits>
class Stack{
    private:
        int *data;
        int nextIndex;
        int capacity;
    public:
        Stack(int size){
            data = new int[size];
            this->capacity = size;
            nextIndex=-1;
        }
        int isEmpty(){
            return nextIndex==-1;
        }
        void push(int element){
            if(nextIndex==capacity-1){
                cout<<"Stack full"<<endl;
                return ;
            }
            data[nextIndex] =element;
            nextIndex++;
        }
        int pop(){
            if(isEmpty()){
                cout<<"Stack is empty"<<endl;
                return INT_MIN;
            }
            nextIndex--;
            return data[nextIndex];
        }
        int size(){
            return nextIndex;
        }
        int top(){
            return data[nextIndex-1];
        }
};