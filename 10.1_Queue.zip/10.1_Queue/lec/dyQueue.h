template<typename T>
class Queue{
    int capacity;
    int nextIndex;
    int firstIndex;
    int size;
    T *data;
    public:
    Queue(){
        data = new T[4];
        nextIndex=0;
        capacity = 4;
        firstIndex =-1;
        size = 0;
    }
    void enqueue(T element){
        if (size==capacity)
        {
            T *newData = new T[2*capacity];
            int j=0;
            for (int i = firstIndex; i < capacity; i++)
            {
                newData[j] = data[i];
                j++;
            }
            for (int i = 0; i < firstIndex; i++)
            {
                newData[j] = data[i];
                j++;
            }
            delete[] data;
            data = newData;
            firstIndex =0;
            nextIndex = capacity;
            capacity*=2;
        }
        data[nextIndex] = element;
        nextIndex = (nextIndex + 1)%capacity;
        if (firstIndex==-1)
        {
            firstIndex=0;
        }     
        size++;
    }
    T front(){
        if(isEmpty()){
            cout<<"Queue is empty";
            return 0;
        }
        return data[firstIndex];
    }
    int isEmpty(){
        return size==0;
    }
    T dequeue(){
        if (isEmpty())
        {
            cout<<"Queue is empty"<<endl;
            return 0;
        }
        T temp = data[firstIndex];
        firstIndex = (firstIndex+1)%capacity;
        size--;
        return temp;
    }
    int getSize(){
        return size;
    }
};