#include<iostream>
#include<queue>
using namespace std;

int main(){
    queue<int> q;
    q.push(50);
    q.push(60);
    q.push(70);
    q.push(80);
    q.push(90);

    q.pop();
    cout<<q.front()<<endl;
    cout<<q.size()<<endl;
    cout<<q.empty()<<endl;
    return 0;
}