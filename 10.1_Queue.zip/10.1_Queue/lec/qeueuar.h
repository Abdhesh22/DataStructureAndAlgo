template<typename T>
class Queue{
    int capacity;
    int nextIndex;
    int firstIndex;
    int size;
    T *data;
    public:
    Queue(int Size){
        data = new T[size];
        nextIndex=0;
        capacity = Size;
        firstIndex =-1;
        size = 0;
    }
    void enqueue(T element){
        if (size==capacity)
        {
            cout<<"Queue full"<<endl;
            return ;
        }
        data[nextIndex] = element;
        nextIndex = (nextIndex + 1)%capacity;
        if (firstIndex==-1)
        {
            firstIndex=0;
        }     
        size++;
    }
    T front(){
        if(isEmpty()){
            cout<<"Queue is empty";
            return 0;
        }
        return data[firstIndex];
    }
    int isEmpty(){
        return size==0;
    }
    T dequeue(){
        if (isEmpty())
        {
            cout<<"Queue is empty"<<endl;
            return 0;
        }
        T temp = data[firstIndex];
        firstIndex = (firstIndex+1)%capacity;
        size--;
        return temp;
    }
    int getSize(){
        return size;
    }
};