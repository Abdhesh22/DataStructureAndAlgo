//rotation of array
#include<bits/stdc++.h>
using namespace std;

void setArray(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }    
}

void leftrotateArrayByOne(int arr[],int n){
    int temp = arr[0];
    for (int i = 0; i < n-1; i++)
    {
        arr[i] = arr[i+1];
    }
    arr[n-1] = temp;
}

void leftrotateArray(int arr[],int n,int index){
    for (int i = 0; i < index; i++)
    {
        leftrotateArrayByOne(arr,n);
    }    
}

void printArray(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main(){
    int n,index;
    cin>>n;
    int *arr = new int[n];
    setArray(arr,n);
    cin>>index;
    leftrotateArray(arr,n,index);
    printArray(arr,n);
    delete [] arr;
    return 0;
}