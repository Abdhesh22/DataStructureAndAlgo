#include<bits/stdc++.h>
using namespace std;

void setArray(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }
    
}

// int pairSum(int arr[],int n,int num){
//     int count = 0;
//     for (int i = 0; i < n-1; i++){
//         for(int j=i+1;j<n;j++)                              //o(n^2);
//     {
//         if(arr[i]  + arr[j] == num){
//             count++;
//         }
//     }
//     }
//     return count;
// }

int pairSum(int arr[],int n,int num){
    int i=0,j=n-1,count=0;
    sort(arr,arr+n);
    while (i<j)
    { 
        if (arr[i] + arr[j] == num){
            count++;
        }else if(arr[i] + arr[j] > num){
            j--;
        }else{
            i++;
        }            
    }
    return count;
}

int main(){
    int n,num;
    cin>>n;
    int *arr =  new int[n];
    setArray(arr,n);
    cin>>num;
    cout<< pairSum(arr,n,num);
    return 0;
}