//find the unique element.
#include<bits/stdc++.h>
using namespace std;

void setArray(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }
    
}

int UniqueEle(int arr[],int n){
    sort(arr,arr+n);
    for (int i = 0; i < n; i++)
    {
        if (arr[i] ==arr[i+1])
        {
            i++;
        } else{
            return arr[i];
        }       
    }
    return -1;
}

int main(){
    int n;
    cin>>n;
    int *arr = new int[n];
    setArray(arr,n);
    cout<<UniqueEle(arr,n);
    delete [] arr;
    return 0;
}