#include<iostream>
using namespace std;

class Node{
    public:
        int Data;
        Node *Next;
    Node(int Data){
        this->Data = Data;
        this->Next = NULL; 
    }
};

Node * Linklist(){
    int Data;
    cin>>Data;
    Node * Head = NULL;
    Node * tail = NULL;
    while (Data != -1)
    {
        Node * newNode = new Node(Data);
        if (Head == NULL)
        {
            Head=newNode;
            tail =newNode;
        }else{
            tail->Next = newNode;
            tail = tail->Next;
        }
        cin>>Data;
    }
    return Head;
}

void print(Node * head){
        Node *temp = head;
        while (temp!=NULL)
        {
            cout<<temp->Data<<" ";
            temp = temp->Next;
        }     
        cout<<endl;   
}

int getMid(Node *head){
    Node * temp = head;
    int count=0;
    while (temp != NULL)
    {
        temp=temp->Next;
        count++;
    }
    int n = (count-1)/2;
    count = 0;
    temp = head;
    while (count<n)
    {
        temp = temp->Next;
        count++;
    }
    return temp->Data;
}

int getmidWithoutSize(Node * head){
    Node * slow = head;
    Node * fast = head->Next;
    while (fast != NULL && fast->Next != NULL ) //1->2->3->4->5
    {
        slow = slow->Next;
        fast = fast->Next->Next;
    }
    return slow->Data;
}

int main(){
    Node *head = Linklist();
    print(head);
    int n = getmidWithoutSize(head);
    cout<<n;
    return 0;
}