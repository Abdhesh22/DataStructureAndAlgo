#include<iostream>
using namespace std;
#include "1.0TreeImplement.h"
//this is generic tree
TreeNode<int>* Takeinput(){
    int rootdata;
    cout<<"Enter the Data: ";
    cin>>rootdata;
    TreeNode<int> * root = new TreeNode<int>(rootdata);
    int n;
    cout<<"Enter the number of child of  "<<rootdata<<endl;
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        //Takeinput(); now we have to connect the nodes.
        TreeNode<int> * child = Takeinput();
        root->children.push_back(child);
    }
    return root;
}
template<typename S>
void printTree(TreeNode<S> * root){
    if(root ==NULL){ //edge case when someone gives NULL pointer
        return;
    }
    cout<<root->data<<" : ";
    for (int i = 0; i < root->children.size(); i++)
    {
        cout<<root->children[i]->data<<" , ";
    }
    cout<<endl;
    for (int i = 0; i < root->children.size(); i++){
        printTree(root->children[i]);
    }
}

int main(){
    // TreeNode<int> * Root = new TreeNode<int>(1);
    // TreeNode<int> *  Node1= new TreeNode<int>(2);
    // TreeNode<int> * Node2 = new TreeNode<int>(3);

    // Root->children.push_back(Node1);
    // Root->children.push_back(Node2);
    TreeNode<int> * Root = Takeinput();
    printTree(Root);
    return 0;
}