#include<iostream>
using namespace std;
#include "1.0TreeImplement.h"

int main(){
    TreeNode<int >* root = new TreeNode<int>(1);
    TreeNode<int >* node1 = new TreeNode<int>(2);
    TreeNode<int >* node2 = new TreeNode<int>(3);

    root->children.push_back(node1);
    root->children.push_back(node2);

    return 0;
}