//sum of array
#include<iostream>
using namespace std;

void getArray(int arr[], int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }
}

int sumOfArray(int arr[],int n, int sum = 0){
    if(n==0){
        return sum;
    }
    sum +=arr[0];
    return sumOfArray(arr+1,n-1,sum);
}

int main(){
    int n;
    cin>>n;
    int *arr = new int[n];
    getArray(arr,n);
    int sum = sumOfArray(arr,n);
    cout<<sum;
    delete [] arr;
    return 0;
}