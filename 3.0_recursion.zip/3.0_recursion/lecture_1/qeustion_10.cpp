#include<iostream>
using namespace std;

void getArray(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }    
}
bool searchArray(int arr[], int n, int element){
    if (n==0)
    {
        return false;
    }
    if (element == arr[0])
    {
        return  true;
    }
    return searchArray(arr+1,n-1,element);    
}

int main(){
    int n,element;
    cin>>n;
    int *arr = new int[n];
    getArray(arr,n);
    cin>>element;
    bool search = searchArray(arr,n,element);
    cout<<search;
    delete [] arr;
    return 0;
}