#include<iostream>
using namespace std;
//print the number
// input 6
//output 6 5 4 3 2 1
int printNum(int n){
    if(n<=0){
        return 0;
    }
    printNum(n-1);
    cout<<n<<" ";
    return 0;
}

int main(){
    int n;
    cin>>n;
    printNum(n);
    return 0;
}