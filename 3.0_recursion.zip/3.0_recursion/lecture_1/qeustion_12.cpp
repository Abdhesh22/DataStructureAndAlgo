#include<iostream>
using namespace std;

void getArray(int arr[], int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }
}

// int searchArr(int arr[],int n,int element, int index=0,int lastIndex=-1){
//     if(n==0){
//         return lastIndex;
//     }
//     if(element==arr[0]){
//         if (lastIndex<index)
//         {
//             lastIndex = index;
//         }
//     }
//     return searchArr(arr+1,n-1,element,index+1,lastIndex);
// }


// bestSolution
int searchArr(int arr[],int n,int element){
    if(n==0){
        return -1;
    }
    if(element==arr[n]){
        return n;
    }
    return searchArr(arr,n-1,element);
}

int main(){
    int n,element;
    cin>>n;
    int *arr = new int[n];
    getArray(arr,n);
    cin>>element;
    int search = searchArr(arr,n,element);
    cout<<search;
    delete [] arr;
    return 0;
}