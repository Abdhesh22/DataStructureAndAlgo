#include<iostream>
using namespace std;

int numberOfDigit(int n,int count=0){
    if(n<=0){
        return count;
    }
    count++;
    n=n/10;
    return numberOfDigit(n,count);
}

int main(){
    int n;
    cin>>n;
    cout<<numberOfDigit(n);
    return 0;
}