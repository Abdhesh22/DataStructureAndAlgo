#include<iostream>
using namespace std;

void getArray(int arr[], int n){
    for (int i = 0; i < n; i++)
    {
        cin>>arr[i];
    }   
}

int searchIndex(int arr[], int n, int element,int index=0){
    if(n==0){//basecondition
        return -1;
    }
    if (element ==  arr[0])
    {
        return index;              //small calculation
    }
    return searchIndex(arr+1,n-1,element,index+1);// recursive call
    
}
int main(){
    int n,element;
    cin>>n;
    int *arr = new int[n];
    getArray(arr,n); 
    cin>>element;
    int index = searchIndex(arr,n,element);
    cout<<index;
    delete []arr;
    return 0;
}