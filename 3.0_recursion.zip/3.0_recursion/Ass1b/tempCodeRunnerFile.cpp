string changeString(str s){
//      if(){
//          return " ";
//     }

// }