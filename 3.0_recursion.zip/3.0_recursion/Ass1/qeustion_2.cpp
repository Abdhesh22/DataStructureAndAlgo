#include<iostream>
using namespace std;

int countZeros(int n,int k){
    if(n==0){
        return 0;
    }  
    int digit = n%10; 
    if(digit == k){
        return 1 + countZeros(n/10,k);
    }
    return countZeros(n/10,k);
}

int main(){
    int n;
    int k = 0;
    cin>>n;
    cout<<countZeros(n,k);
    return 0;
}