#include<iostream>
#include<math.h>
using namespace std;

float geometric(int n){
    if(n==0){
        return 1;
    }
    return 1/pow(2,n) + geometric(n-1);
}

int main(){
    float n;
    cin>>n;
    cout<<geometric(n);
    return 0;
}