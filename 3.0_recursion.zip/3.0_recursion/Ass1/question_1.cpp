#include<iostream>
using namespace std;

int multi(int m, int n){
    if(n==0){
        return 0;  //base case
    }
    return multi(m,n-1) +m;   //solution
}


int main(){
    int m,n;
    cin>>m>>n;
    cout<<multi(m,n);
    return 0;
}