#include<iostream>
using namespace std;

int sumDigit(int n){
    // cout<<"Recursion no. "<<n<<endl; 
    if(n<=0){
        // cout<<"here termination"<<endl;;
        return 0;  //baseCondition
    } 
    cout<<endl;
    return n%10 + sumDigit(n/10);
}
int main(){
    int n;
    cin>>n;
    cout<<sumDigit(n);
    return 0;
}