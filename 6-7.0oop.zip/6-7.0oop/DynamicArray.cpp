#include <bits/stdc++.h>
using namespace std;

class DynamicArray
{
    int *Data;
    int nextIndex;
    int capacity;

public:
    DynamicArray()
    {
        Data = new int[5];
        nextIndex = 0;
        capacity = 5;
        }
    DynamicArray(DynamicArray const &d){  //copy constructor with deep copy
        this->Data =new int[d.capacity];
        for (int i = 0; i < d.nextIndex; i++)
        {
            this->Data[i] = d.Data[i];
        }
        this->nextIndex = d.nextIndex;
        this->capacity = d.capacity;
    }

    void operator=(DynamicArray const &d){   //copy assignment operator with deep copy
        this->Data =new int[d.capacity];
        for (int i = 0; i < d.nextIndex; i++)
        {
            this->Data[i] = d.Data[i];
        }
        this->nextIndex = d.nextIndex;
        this->capacity = d.capacity;

    }

        void Add(int element){
            if (nextIndex == capacity){
                int *newData = new int[2 * capacity];
                for (int i = 0; i < capacity; i++){
                    newData[i] = Data[i];
                }
                delete [] Data;
                Data = newData;
                capacity *= 2;
            }
            Data[nextIndex] = element;
            nextIndex++;        
        }
        int get(int i){
            if(i<nextIndex){
                return Data[i];
            }else{
                return -1;
            }
        }
        void Add(int i,int element){
            if(i<nextIndex){
                Data[i] = element;
            }
            else if(i == nextIndex){
                Add(element);
            }else{
                return;
            }
        }
        void print(){
            for (int i = 0; i < nextIndex; i++)
            {
                cout<<Data[i]<<" ";
            }
            cout<<endl;
        }
};

int main()
{
    DynamicArray d1;
    d1.Add(5);
    d1.Add(6);
    d1.Add(7);
    d1.Add(8);
    d1.Add(9);

    DynamicArray d2(d1);    //Copy Constructo  do shallow copy
    d1.Add(0,100);
    d1.print();
    d2.print();
   // DynamicArray d3;
    //d3 = d2;   //copy assignment both are do shallow copy
    return 0;
}