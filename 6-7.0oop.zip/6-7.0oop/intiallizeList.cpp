#include<bits/stdc++.h>
using namespace std;

//initialization list initialize the value in const variales
//it initialize value at time of memory allocation. 
class Student{
    public:
    int const rollNumber;
    int age;
    int &x; //reference variable
    Student(int r,int age):rollNumber(r), age(age),x(this->age){   //this->age(argument->age), x is  reference that refers the addres of age. 
        // rollNumber = r;
    }
    void print(){
        cout<<"Age:"<<this->age<<" RollNumber: "<<this->rollNumber<<endl;
    }
};

int main(){
    Student s1(10,20);
    s1.print();
    return 0;
}