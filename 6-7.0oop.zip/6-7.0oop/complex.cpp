#include<iostream>
using namespace std;

class ComplexNumber{
    private:
        int real;
        int image;
    public:
        ComplexNumber(int real,int image){
            this->real =  real;
            this->image = image;
        }
        void print(){
            cout<<this->real<<" + "<<this->image<<"i"<<endl;
        }
        void add(ComplexNumber const &c2){
            this->real =  this->real + c2.real;
            this->image = this->image + c2.image;
        }
        void multiply(ComplexNumber const &c2){
            this->real =  this->real * c2.real;
            this->image = this->image * c2.image;
        }
};

int main(){
    ComplexNumber c1(3,4);
    c1.print();
    ComplexNumber c2(4,5);
    c2.print();
    c1.add(c2);
    c1.print();
    c1.multiply(c2);
    c1.print();
    return 0;
}