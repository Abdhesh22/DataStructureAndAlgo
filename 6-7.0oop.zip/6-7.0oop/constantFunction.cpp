#include <iostream>
using namespace std;

class Factor
{
private:
    int numinator;
    int dominator;

public:
    Factor()
    {
    }
    Factor(int numinator, int dominator)
    {
        this->numinator = numinator;
        this->dominator = dominator;
    }
    int getNumerator() const
    {
        return numinator;
    }
    int getdominator() const
    {
        return dominator;
    }

    void setNumerator(int n)
    {
        numinator = n;
    }
    void setdominator(int d)
    {
        dominator = d;
    }

    void print() const
    {
        cout << this->numinator << "/" << dominator << endl;
    }
    void simplify()
    {
        int gcd = 1;
        int j = min(this->numinator, this->dominator);
        for (int i = 1; i <= j; i++)
        {
            if (this->numinator % i == 0 && this->dominator % i == 0)
            {
                gcd = i;
            }
        }
        this->numinator = this->numinator / gcd;
        this->dominator = this->dominator / gcd;
    }
    void add(Factor const &f2)
    {
        int lcm = this->dominator * f2.dominator;
        int x = lcm / this->dominator;
        int y = lcm / f2.dominator;
        this->numinator = x * this->numinator + (y * f2.numinator);
        this->dominator = lcm;
        simplify();
    }
    void mul(Factor const &f2)
    {
        this->numinator = this->numinator * f2.numinator;
        this->dominator = this->dominator * f2.dominator;
        simplify();
    }
};

int main()
{
    Factor *f1 = new Factor(2, 3);
    Factor *f2 = new Factor(5, 6);

    Factor const f3; //we can't call function using constant object using constant object we can call only constant function.
    cout<<f3.getdominator()<<" "<<f3.getNumerator()<<endl;
    return 0;
}