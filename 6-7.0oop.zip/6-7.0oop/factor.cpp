#include<iostream>
using namespace std;

class Factor{
    private:
        int numinator;
        int dominator;
    public:
        Factor(int numinator, int dominator){
            this->numinator = numinator;
            this->dominator = dominator;
        }
        void print(){
            cout<<this->numinator<<"/"<<dominator<<endl;
        }
        void simplify(){
            int gcd =1;
            int j = min(this->numinator,this->dominator);
            for (int i = 1; i <= j; i++)
            {
                if (this->numinator% i == 0 && this->dominator % i ==0 )
                {
                    gcd = i;
                }
                
            }
            this->numinator = this->numinator/gcd;
            this->dominator = this->dominator/gcd;
        }
        void add(Factor const &f2){
                int lcm = this->dominator * f2.dominator;
                int x = lcm/this->dominator;
                int y = lcm/f2.dominator;
                this ->numinator = x * this->numinator + (y*f2.numinator);
                this->dominator = lcm;
                simplify();
        }
        void mul(Factor const &f2){
            this->numinator = this->numinator * f2.numinator;
            this->dominator = this->dominator * f2.dominator;
            simplify();
        }
};

int main(){
    Factor *f1 = new Factor(2,3);
    f1->print();    
    Factor *f2 = new Factor(5,6);
    f2->print();
    f1->add(*f2);
    f1->print();
    f1->mul(*f2);
    f1->print();
    return  0;
}