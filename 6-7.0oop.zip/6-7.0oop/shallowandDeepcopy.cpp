#include<bits/stdc++.h>
using namespace std;

class Student{
    int age;
    char *name;
    public:
        Student(int age,char *name){
            this->age = age;
            
            //Shallow copy
            // this->name = name;

            //Deep copy
            this->name = new char[strlen(name) + 1];   //creating array
            strcpy(this->name,name);  //copy array

        }
        void print(){
            cout<<"Age: "<<this->age<<endl;
            cout<<"Name: "<<this->name<<endl;
        }
};

int main(){
    char name[] = "abcd";
    Student S1(10,name);
    S1.print();

    name[2] = 'd';
    Student S2(12,name);
    S1.print();
    S2.print();
    return 0;
}