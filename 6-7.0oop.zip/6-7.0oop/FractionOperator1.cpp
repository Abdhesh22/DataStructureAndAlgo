#include <bits/stdc++.h>
using namespace std;

class Fraction
{
private:
    int numerator;
    int denominator;

public:
    Fraction(int numerator, int denominator)
    {
        this->numerator = numerator;
        this->denominator = denominator;
    }
    void Display() const
    {
        cout << this->numerator << "/" << this->denominator << endl;
    }
    void simpleFy()
    {
        int gcd = 1;
        int j = min(numerator, denominator);
        for (int i = 1; i <= j; i++)
        {
            if (this->numerator % i == 0 && this->denominator % i == 0)
            {
                gcd = i;
            }
        }
        this->numerator = this->numerator / gcd;
        this->denominator = this->denominator / gcd;
    }
    Fraction operator+(Fraction const &f2) const
    {
        int lcm = this->denominator * f2.denominator; // 2*2 =4
        int x = lcm / this->denominator;              // 4/2  = 2
        int y = lcm / f2.denominator;                 //4/2    = 2
        int n = x * this->numerator + y * f2.numerator;
        Fraction newFraction(n, lcm);
        newFraction.simpleFy();
        return newFraction;
    }
    Fraction operator*(Fraction const &f2) const
    {
        int n = this->numerator * f2.numerator;
        int d = this->denominator * f2.denominator;
        Fraction newFraction(n, d);
        newFraction.simpleFy();
        return newFraction;
    }
    bool operator==(Fraction const &f2) const
    {
        return (this->numerator == f2.numerator && this->denominator == f2.denominator);
    }
    Fraction& operator++(){   //pre-increment
        numerator = numerator + denominator;
        simpleFy();
        return *this;
    }
    Fraction operator++(int){
        Fraction fNew(numerator,denominator);
        numerator = numerator + denominator;
        simpleFy();
        return fNew;
    }
    Fraction& operator+=(Fraction const &f2){
        int lcm = this->denominator * f2.denominator; // 2*2 =4
        int x = lcm / this->denominator;              // 4/2  = 2
        int y = lcm / f2.denominator;                 //4/2    = 2
        int n = x * this->numerator + (y * f2.numerator);
       numerator = n;
       denominator = lcm;
       simpleFy();
        return *this;
    }
};

int main()
{
    Fraction f1(1, 2);
    Fraction f2(1, 4);
    Fraction f3 = f1 + f2;
    Fraction f4 = f1 * f2;
    f1.Display();
    f2.Display();
    f3.Display();
    f4.Display();
    if (f1 == f2)
    {
        cout << "Equal" << endl;
    }
    else
    {
        cout << "Not equal" << endl;
    }
    Fraction f5 = ++(++f1);  //pre-increment call.
    f1.Display();
    f5.Display();

    Fraction f6 = f2++;  //post-increment call nesting is not allowed on it.
    f6.Display();
    f2.Display();

    Fraction f7(1,2);
    f7+=f1;
    f7.Display();

    return 0;
}