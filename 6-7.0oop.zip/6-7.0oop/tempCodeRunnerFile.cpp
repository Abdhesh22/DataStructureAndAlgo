int main() {
    short t;
    cin>>t;
    while(--t){
    short a,b,c,d,e;
    cin>>a>>b>>c>>d>>e;
    if((a+b<d || b+c<d || c+a<d)&&(a<e ||b<e || c<e)){
        cout<<"Yes";
    }else{
        cout<<"No";
    }
    }
	return 0;
}