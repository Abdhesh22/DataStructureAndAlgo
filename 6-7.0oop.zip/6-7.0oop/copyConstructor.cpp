#include<bits/stdc++.h>
using namespace std;

class Student{
    int rollNumber;
    public:
    char *name;
    Student(int rollNumber, char *name){
        this->rollNumber = rollNumber;
        //Deep copy
        this->name = new char[strlen(name) + 1];  //create array
        strcpy(this->name,name);//copy array
    }

//copy constructor
    Student(Student const &S){
        this->rollNumber = S.rollNumber;
        //deep copy
        this->name = new char[strlen(S.name) + 1];
        strcpy(this->name,S.name);
    }
    void print(){
        cout<<"RollNumber: "<<this->rollNumber<<endl<<"Name: "<<this->name<<endl;
    }    
};

int main(){
    char name[] = "abcd";
    Student S1(20,name);
    S1.print();

    Student S2(S1);
    S2.print();
    return 0;
}
