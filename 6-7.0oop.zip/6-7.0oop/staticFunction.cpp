#include<bits/stdc++.h>
using namespace std;

class Student{
    public:
    int rollnumber;
    int age;

    static int totalStudent;//total number of student present,  :: scope resolution operator.
    Student(){
        totalStudent++;
    }
    int getRollNumber(){
        return rollnumber;
    }
    static int getTotalStudent(){   //this function belong to a complete class
        return totalStudent;
    }
};

int Student :: totalStudent = 0; //initialize static data member

int main(){
    Student s1;
    cout<<s1.rollnumber<<endl;
    cout<<s1.age<<endl;
    cout<<Student :: totalStudent<<endl;  //logically correct
    // cout<<s1.totalStudent<<endl; //this is logically incorrect.
    // s1.totalStudent =  20;

    Student s2;
    // cout<<s2.totalStudent<<endl; //this is logically incorrect
    cout<<Student :: totalStudent<<endl;
    cout<<Student::getTotalStudent()<<endl;
    return 0;
}