#include<iostream>
using namespace std;

class Student  {
    private:
    int age;
    public:
    int rollnumber;
    Student(){
        cout<<"constructor called successfully";
    }
    Student(int age){
        this->age = age;   //this keyword save the address of current object. 
    }
    Student(int age,int rollnumber){
        this->rollnumber=rollnumber;
        this->age = age; 
    }
    void getData(){
        cout<<"Roll number  is "<<this->rollnumber<<endl;
        cout<<"Age is "<<this->age<<endl;
    }
    ~Student(){
        cout<<"Destructor called"<<endl;
    }
};

int main(){
    Student s4;   //constructor called
    s4.getData();

    Student s6(s4);//this is copy constructor too

    Student *s1 =  new Student(); 
    s1->getData();

    Student *s2 = new Student(5);  //constructor 2 called
    s2->getData();

    Student *s3 =  new Student(5,1001);  //constructor 3 called
    s3->getData();

    Student *s4 = new Student(*s3);  //copy constructor called;

    delete s3;
    delete s2;
    delete s1;
    return 0;
}