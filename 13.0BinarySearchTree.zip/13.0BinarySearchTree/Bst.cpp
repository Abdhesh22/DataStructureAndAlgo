#include<iostream>
using namespace std;
#include "lec18Bst.h"

int main(){
    Bst b;
    b.insert(10);
    b.insert(5);
    b.insert(20);
    b.insert(3);
    b.insert(7);
    b.insert(15);
    b.printTree();
    b.deleteData(20);
    b.printTree();
    return 0;
}