#include<bits/stdc++.h>
using namespace std;
#include "lec1BinaryTree.h"
BinaryTreeNode<int> * takeInput(){
    int rootData;
    cout<<"Enter root data"<<endl;
    cin>>rootData;
    if(rootData == -1){
        return NULL;
    }
    BinaryTreeNode<int> * root =   new BinaryTreeNode<int>(rootData);
    queue<BinaryTreeNode<int>*> pendingNodes;
    pendingNodes.push(root);
    while (pendingNodes.size() != 0)
    {
        BinaryTreeNode<int> * front =  pendingNodes.front();
        pendingNodes.pop();
        cout<<"Enter the leftchild of: "<<front->data<<endl;
        int leftchild;
        cin>>leftchild;
        if (leftchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(leftchild);
            front->left =  child;
            pendingNodes.push(child);
        }
        cout<<"Enter the rightchild of: "<<front->data<<endl;
        int rightchild;
        cin>>rightchild;
        if (rightchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(rightchild);
            front->right =  child;
            pendingNodes.push(child);
        }
    }
    return root;
} 
void printTree(BinaryTreeNode<int> * root){
    if(root == NULL){
        return;
    }
    cout<<root->data<<" : ";
    if(root->left != NULL){
        cout<<"L " <<root->left->data<<" ";
    }
    if(root->right != NULL){
        cout<<"R "<<root->right->data<<" ";
    }
    cout<<endl;
    printTree(root->left);
    printTree(root->right);
}

void printLevelWise(BinaryTreeNode<int> * root){
    queue<BinaryTreeNode<int>*>  pendingNodes;
    pendingNodes.push(root);
    while (pendingNodes.size()!=0)
    {
        BinaryTreeNode<int> * front = pendingNodes.front();
        cout<<front->data<<":";
        pendingNodes.pop();
        if(front->left != NULL){
            cout<<"L"<<front->left->data<<" ";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout<<"R"<<front->right->data<<" ";
            pendingNodes.push(front->right);
        }
        cout<<endl;
    }
}
int numNodes(BinaryTreeNode<int> * root){
    if(root == NULL){
        return 0;
    }
    return 1+numNodes(root->left) + numNodes(root->right);
}

void inOrder(BinaryTreeNode<int> * root){
    if(root == NULL){
        return;
    }
    inOrder(root->left);
    cout<<root->data<<" ";
    inOrder(root->right);
}

BinaryTreeNode<int> * buildTreeHelper(int *in,int *pre,int inS,int inE,int preS, int preE){
    if(inS>inE){
        return NULL;
    }
    int rootData = pre[preS];
    int rootIndex =-1;
    for (int i = inS; i <= inE; i++)
    {
        if(in[i]==rootData){
            rootIndex = i;
            break;
        }
    }
    int lInS = inS;
    int lInE = rootIndex-1;
    int lPreS = preS +1;
    int lPreE = lInE - lInS + lPreS;
    int rPreS = lPreE +1;
    int rPreE = preE;
    int rInS = rootIndex +1;
    int rInE = inE;

    BinaryTreeNode<int> * root = new BinaryTreeNode<int>(rootData);
    root->left = buildTreeHelper(in,pre,lInS,lInE,lPreS,lPreE);
    root->right = buildTreeHelper(in,pre,rInS,rInE,rPreS,rPreE);
    return root;
}
BinaryTreeNode<int> * buildTree(int *in, int *pre,int size){
    return buildTreeHelper(in,pre,0,size-1,0,size-1);
}

int height(BinaryTreeNode<int> *  root){
    if(root==NULL){
        return 0;
    }
    return 1+max(height(root->left),height(root->right));
}

int diameter(BinaryTreeNode<int>*root){
    if(root==NULL){
        return 0;
    }
    int option1 = height(root->left) + height(root->right);
    int option2 = diameter(root->left);
    int option3 = diameter(root->right);
    return max(option1,max(option2, option3));
}

pair<int,int> heightDiameter(BinaryTreeNode<int> * root){
    if(root==NULL){
        pair<int,int> p;
        p.first = 0;
        p.second = 0;
        return p;
    }
    pair<int, int> leftAns = heightDiameter(root->left);
    pair<int, int> rightAns = heightDiameter(root->right);
    int ld = leftAns.second;
    int lh = leftAns.first;
    int rd = rightAns.second;
    int rh = rightAns.first;

    int heighT = 1+max(lh,rh);
    int diaMeter = max(lh+rh,max(ld,rd));
    pair<int,int> p;
    p.first = heighT;
    p.second = diaMeter;
    return p;
}

BinaryTreeNode<int> * Bstsearch(BinaryTreeNode<int> * root,int sdata){
    if (root == NULL || root->data == sdata)
    {
        return root;
    }
    if (root->data < sdata)
    {
        return Bstsearch(root->right,sdata);
    }
    return Bstsearch(root->left,sdata);
}


void rangePrint(BinaryTreeNode<int> *root, int start,int end){
    if(NULL == root){
        return;
    }
    if(start<root->data){
        rangePrint(root->left,start,end);
    }
    if(start<=root->data && end>=root->data){
        cout<<root->data<<" ";
    }
    rangePrint(root->right,start,end);
}

int maximum(BinaryTreeNode<int> * root){
    if(root == NULL){
        return INT_MIN;
    }
    return max(root->data,max(maximum(root->left),maximum(root->right)));
}

int minimum(BinaryTreeNode<int> * root){
    if(root==NULL){
        return INT_MAX;
    }
    return min(root->data,min(minimum(root->left),minimum(root->right)));
}

bool isBst(BinaryTreeNode<int> * root){
    if(root==NULL){
        return true;
    }
    int leftmax = maximum(root->left);
    int rightmin =  minimum(root->right);
    bool output = (root->data > leftmax) && (root->data <= rightmin) && isBst(root->left) && isBst(root->right);
    return output;
}

int main(){

    //4 2 6 1 3 5 7 -1 -1 -1 -1 -1 -1 -1 -1
    BinaryTreeNode<int> *root = takeInput();
    printLevelWise(root);
    // cout<<"Enter data do you want to search: "<<endl;
    // int n;
    // cin>>n;
    // BinaryTreeNode<int> *searchnode=   Bstsearch(root,n);
    // cout<<searchnode->data;
    // int start,end;
    // cout<<"Enter the range for printing the node data"<<endl;
    // cin>>start>>end;
    // rangePrint(root,start,end);
    cout<<isBst(root);
    return 0;
}