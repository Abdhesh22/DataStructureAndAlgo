#include<iostream>
using namespace std;
#include "BinaryTreeImplementation.h"
#include<queue>
BinaryTreeNode<int> * takeInput(){
    int rootData;
    cout<<"Enter root data"<<endl;
    cin>>rootData;
    if(rootData == -1){
        return NULL;
    }
    BinaryTreeNode<int> * root =   new BinaryTreeNode<int>(rootData);
    queue<BinaryTreeNode<int>*> pendingNodes;
    pendingNodes.push(root);
    while (pendingNodes.size() != 0)
    {
        BinaryTreeNode<int> * front =  pendingNodes.front();
        pendingNodes.pop();
        cout<<"Enter the leftchild of: "<<front->data<<endl;
        int leftchild;
        cin>>leftchild;
        if (leftchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(leftchild);
            front->left =  child;
            pendingNodes.push(child);
        }
        cout<<"Enter the rightchild of: "<<front->data<<endl;
        int rightchild;
        cin>>rightchild;
        if (rightchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(rightchild);
            front->right =  child;
            pendingNodes.push(child);
        }
    }
    return root;
} 
void printTree(BinaryTreeNode<int> * root){
    if(root == NULL){
        return;
    }
    cout<<root->data<<" : ";
    if(root->left != NULL){
        cout<<"L " <<root->left->data<<" ";
    }
    if(root->right != NULL){
        cout<<"R "<<root->right->data<<" ";
    }
    cout<<endl;
    printTree(root->left);
    printTree(root->right);
}
int main(){
    BinaryTreeNode<int> * root = takeInput();
    printTree(root);
    return 0;
}