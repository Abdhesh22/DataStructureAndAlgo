#include<iostream>
using namespace std;
#include "BinaryTreeImplementation.h"
#include<queue>
BinaryTreeNode<int> * takeInput(){
    int rootData;
    cout<<"Enter root data"<<endl;
    cin>>rootData;
    if(rootData == -1){
        return NULL;
    }
    BinaryTreeNode<int> * root =   new BinaryTreeNode<int>(rootData);
    queue<BinaryTreeNode<int>*> pendingNodes;
    pendingNodes.push(root);
    while (pendingNodes.size() != 0)
    {
        BinaryTreeNode<int> * front =  pendingNodes.front();
        pendingNodes.pop();
        cout<<"Enter the leftchild of: "<<front->data<<endl;
        int leftchild;
        cin>>leftchild;
        if (leftchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(leftchild);
            front->left =  child;
            pendingNodes.push(child);
        }
        cout<<"Enter the rightchild of: "<<front->data<<endl;
        int rightchild;
        cin>>rightchild;
        if (rightchild != -1)
        {
            BinaryTreeNode<int> * child = new BinaryTreeNode<int>(rightchild);
            front->right =  child;
            pendingNodes.push(child);
        }
    }
    return root;
} 
void printTree(BinaryTreeNode<int> * root){
    if(root == NULL){
        return;
    }
    cout<<root->data<<" : ";
    if(root->left != NULL){
        cout<<"L " <<root->left->data<<" ";
    }
    if(root->right != NULL){
        cout<<"R "<<root->right->data<<" ";
    }
    cout<<endl;
    printTree(root->left);
    printTree(root->right);
}

void printLevelWise(BinaryTreeNode<int> * root){
    queue<BinaryTreeNode<int>*>  pendingNodes;
    pendingNodes.push(root);
    while (pendingNodes.size()!=0)
    {
        BinaryTreeNode<int> * front = pendingNodes.front();
        cout<<front->data<<":";
        pendingNodes.pop();
        if(front->left != NULL){
            cout<<"L"<<front->left->data<<" ";
            pendingNodes.push(front->left);
        }
        if (front->right != NULL)
        {
            cout<<"R"<<front->right->data<<" ";
            pendingNodes.push(front->right);
        }
        cout<<endl;
    }
}
int numNodes(BinaryTreeNode<int> * root){
    if(root == NULL){
        return 0;
    }
    return 1+numNodes(root->left) + numNodes(root->right);
}

void inOrder(BinaryTreeNode<int> * root){
    if(root == NULL){
        return;
    }
    inOrder(root->left);
    cout<<root->data<<" ";
    inOrder(root->right);
}

BinaryTreeNode<int> * buildTreeHelper(int *in,int *pre,int inS,int inE,int preS, int preE){
    if(inS>inE){
        return NULL;
    }
    int rootData = pre[preS];
    int rootIndex =-1;
    for (int i = inS; i <= inE; i++)
    {
        if(in[i]==rootData){
            rootIndex = i;
            break;
        }
    }
    int lInS = inS;
    int lInE = rootIndex-1;
    int lPreS = preS +1;
    int lPreE = lInE - lInS + lPreS;
    int rPreS = lPreE +1;
    int rPreE = preE;
    int rInS = rootIndex +1;
    int rInE = inE;

    BinaryTreeNode<int> * root = new BinaryTreeNode<int>(rootData);
    root->left = buildTreeHelper(in,pre,lInS,lInE,lPreS,lPreE);
    root->right = buildTreeHelper(in,pre,rInS,rInE,rPreS,rPreE);
    return root;
}
BinaryTreeNode<int> * buildTree(int *in, int *pre,int size){
    return buildTreeHelper(in,pre,0,size-1,0,size-1);
}

int height(BinaryTreeNode<int> *  root){
    if(root==NULL){
        return 0;
    }
    return 1+max(height(root->left),height(root->right));
}

int diameter(BinaryTreeNode<int>*root){
    if(root==NULL){
        return 0;
    }
    int option1 = height(root->left) + height(root->right);
    int option2 = diameter(root->left);
    int option3 = diameter(root->right);
    return max(option1,max(option2, option3));
}

int main(){
    int in[] = {4,2,5,1,8,6,9,3,7};
    int pre[] ={1,2,4,5,3,6,8,9,7}; 
    BinaryTreeNode<int> * root = buildTree(in,pre,9);
    printLevelWise(root);
    cout<<endl;
    cout<<numNodes(root)<<endl;
    inOrder(root);
    cout<<endl;
    cout<<"Height: "<<height(root)<<endl;
    cout<<"diameter: "<<diameter(root)<<endl;
    return 0;
}