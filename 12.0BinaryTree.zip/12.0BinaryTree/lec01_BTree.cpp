#include<iostream>
using namespace std;
#include"BinaryTreeImplementation.h"

int main(){
    BinaryTreeNode<int> * root = new BinaryTreeNode<int>(5);
    BinaryTreeNode<int> * node1 = new BinaryTreeNode<int>(6);
    BinaryTreeNode<int> * node2= new BinaryTreeNode<int>(7);
    root->left = node1;
    root->right = node2;
    return 0;
}