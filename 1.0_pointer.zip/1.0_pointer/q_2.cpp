#include<iostream>
using namespace std;

int main(){
    char *chptr;
    char str[] = "abcdefg";
    chptr =  str;
    chptr += 5;
    cout<<chptr;
    return 0;
}