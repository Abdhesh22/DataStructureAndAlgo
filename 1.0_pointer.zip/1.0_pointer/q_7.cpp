#include<iostream>
using namespace std;

void Q(int z){
    z += z;
    cout<<z<<" ";
}

void P(int *y){
    int x = *y + 2;
    Q(x);
    *y = x-1;
    cout<<x <<" ";
}

int main(){
    int x = 5;
    P(&x);
    cout<<x;
    return 0;
}