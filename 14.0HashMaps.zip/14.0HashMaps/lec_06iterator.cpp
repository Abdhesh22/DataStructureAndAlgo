#include<iostream>
#include<unordered_map>
#include<string>
#include<vector>
using namespace std;

int main(){
    unordered_map<string,int> unMap;
    unMap["abc"] = 1;
    unMap["abc2"] = 2;
    unMap["abc3"] = 3;
    unMap["abc4"] = 4;
    unMap["abc5"] = 5;
    unMap["abc6"] = 6;

    unordered_map<string,int>::iterator it = unMap.begin();
    //find and erase
    unordered_map<string,int>::iterator it2 = unMap.find("abc3");
    // // unMap.erase(it2);
    unMap.erase(it2, it2 + 2);

    while (it != unMap.end())
    {
        cout<<"key "<<it->first<<" value "<<it->second<<endl;
        it++;
    }
    vector<int> v;
    v.push_back(1);
    v.push_back(2);
    v.push_back(3);
    v.push_back(4);
    v.push_back(5);

    vector<int>::iterator it1=v.begin();
    while (it1 != v.end())
    {
        cout<<*it1<<" ";
        it1++;
    }
    return 0;
}