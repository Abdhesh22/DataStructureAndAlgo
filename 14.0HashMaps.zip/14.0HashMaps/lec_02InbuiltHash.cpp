#include<iostream>
#include<unordered_map>
#include<string>
using namespace std;

// map -> log(n);   
// unorderd_map -> log(1);

int main(){
    unordered_map<string,int> outMap;
    //insert 
    pair<string,int> p("abc",1);
    outMap.insert(p);
    outMap["def"] = 2;

    //find or access
    cout<<outMap["abc"]<<endl;
    cout<<outMap.at("abc")<<endl;

    //size
    cout<<"Size: "<<outMap.size()<<endl;
    // cout<<outMap.at("ghi"); //if value not present than it will through a error.
    //cout<<outMap["ghi"];//if it is not present than will inset the value give the value of key is 0.

    if(outMap.count("ghi")>0){   //count function the value .
        cout<<"ghi is present"<<endl;
    }

    //erase 
    outMap.erase("ghi"); //it delete the value from map
    if(outMap.count("ghi")>0){
        cout<<"ghi is present"<<endl;
    }
    return 0;
}