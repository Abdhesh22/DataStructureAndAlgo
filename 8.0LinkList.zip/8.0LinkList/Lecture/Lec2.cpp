#include<bits/stdc++.h>
using namespace std;

class Node{
    public:
    int Data;
    Node *Next;
    Node(int Data){
        this->Data = Data;
        this->Next = NULL;
    }
};

void print(Node *head){
    // while (head != NULL)    //this method is wrong because of it we loose the actual value of head to solve first create a temp pointer after traverse using it(*temp).
    // {
    //     cout<<head->Data<<"->";
    //     head = head->Next;
    // }
    // do
    // {
    //     cout<<"["<<head->Data<<" | "<<head<<"]"<<"->";
    //     head = head->Next;
    // }while (head!=NULL) ; 
    Node *temp = head;
    while (temp!=NULL)
    {
        cout<<temp->Data<<" ";
        temp = temp->Next;
    }
    
}

int main(){
    /*
    Node N1(1);
    Node N2(2);
    Node N3(3);
    Node N4(4);
    Node N5(5);
    //Lets linked the Nodes  head->1->2->3->4->5;
    Node *head = &N1;
    N1.Next = &N2;
    N2.Next = &N3;
    N3.Next = &N4;
    N4.Next = &N5;
    //Lets print the linklist
    print(head);*/

    //Dynamically.

    Node *n1 = new Node(1);
    Node *n2 = new Node(2);
    Node *n3 = new Node(3);
    Node *n4 = new Node(4);
    Node *n5 = new Node(5);

    //lets clear here one thing that is n1,n2,n3 store the address of a block that store the value 1,2,3. 
    //lets links the Nodes.
    Node *head = n1;  //so this how we link it dynamically.
    n1->Next = n2;
    n2->Next = n3;
    n3->Next = n4;
    n4->Next = n5;
    print(head);
    print(head);
    return 0;
}