#include<iostream>
using namespace std;

class Node{
    public:
        int Data;
        Node * Next;
        Node(int Data){
            this->Data =Data;
            this->Next = NULL;
        }
};

Node* takeinput(){
    int data;
    cin>>data;
    Node *head =NULL;
    Node *tail =NULL;
    while(data != -1){
        Node *newNode = new Node(data); //newNode == address of a block
        //this step we doing for linking the nodes
        if(head == NULL){
            head = newNode;
            tail = newNode;
        }else{   //here update the tail inshort tail is going one node to another node
            tail->Next =newNode;  // here link the address
            tail =tail->Next;   //her we update it
        }
        cin>>data;
    }
    return head;
}

Node * insertNodeAtIndex(Node * head,int position,int Data){
    Node *newNode = new Node(Data);
    Node *temp = head;
    int count =0;
    if (position==0)  //only for this we change the return void to node*
    {
        newNode->Next =head;
        head = newNode;
        return head;
    }
    while(temp!=NULL && count<position -1){
        temp = temp->Next;
        count++;
    }
    if(temp!=NULL){
    Node *ptr = temp->Next;
    temp->Next = newNode; 
    newNode->Next =ptr;
    /*
    Another method
    newNode->next = temp->next
    temp->next = newNode
    */  
    }
    return head;
}

void print(Node * head){
    Node * temp = head;
    while (temp != NULL)
    {
        cout<<temp->Data<<" ";
        temp = temp->Next;
    }        
}
int main(){
    Node * head = takeinput();
    print(head);
    int i,Data;
    cin>>i>>Data;
    head = insertNodeAtIndex(head,i,Data);
    print(head);
    return 0;
}