#include<iostream>
using namespace std;

class Node{
    public:
        int Data;
        Node *Next;
        Node(int Data){
            this->Data = Data;
            this->Next = NULL;
        }
};

Node *takeinput(){
    int Data;
    cin>>Data;
    Node * head = NULL;
    Node * tail = NULL;
    while (Data != -1)
    {
        Node * newNode = new Node(Data);
        if (head == NULL)
        {
            head = newNode;  //giving the address of newnode to head
            tail = newNode;  //giving the address of newnode to tail
        }else{
            tail->Next = newNode;
            tail = tail->Next;   //updating the tail
        }
        cin>>Data;
    }
    return head;
}

void print(Node * head){
    Node * temp = head;
    while (temp != NULL)
    {
        cout<<temp->Data<<" ";
        temp = temp->Next;
    } 
    cout<<endl;     
}

Node *insertNodeIndex(Node * head,int Position,int Data){
    Node * newNode = new Node(Data);
    Node *temp = head;
    int count = 0;
    if (Position == 0)   
    {
        newNode->Next = head;
        head = newNode;
        return head;
    }
    
    while (temp != NULL && count<Position-1)
    {
        temp = temp->Next;
        count++;
    }
    if(temp != NULL ){
    newNode->Next = temp->Next;
    temp->Next = newNode;
    }
    return head;
}

Node *deleteUsingIndex(Node * head,int position){
    Node * temp = head;
    int count = 0;
    if(position == 0){
        Node * a = head;
        head = a->Next;
        delete a;
    }else{
    while (temp != NULL && count<position-1)
    {
        temp =  temp->Next;
        count++;
    }
    if(temp != NULL){
    Node * a = temp->Next;
    Node * b = a->Next;
    temp->Next = b;
    delete a;
    }
    }
    return head;
}

int checkedSizeRecursively(Node * head){
    if(head == NULL){
        return 0;
    }else{
    return 1 + checkedSizeRecursively(head->Next);
    }
}

Node * insertIndexRecursion(Node * head,int Data, int i){
    if(head == NULL){
        return head;
    }
    if (i==0)
    {
        Node *newNode = new Node(Data);
        newNode->Next = head;
        return newNode;
    }
    Node * x = insertIndexRecursion(head->Next,Data,i-1);
    head->Next = x;
    return head;
}

Node * delRecursion(Node * head, int i){
    if(head == NULL){
        return NULL;
    }
    if (i==0)
    {
        Node *a = head->Next;
        delete head;
        return a;
    }
    head->Next = delRecursion(head->Next,i-1);
    return head;
}

int main(){
    Node  *head = takeinput();
    print(head);
    // int position,data;
    // cin>>position>>data;
    // head = insertNodeIndex(head,position,data);
    // head =  insertIndexRecursion(head,data,position);
    // print(head);
        int delPosition;
        cin>>delPosition;
//     head = deleteUsingIndex(head,delPosition);
        head = delRecursion(head,delPosition);
        print(head);
//     print(head);
//    int size = checkedSizeRecursively(head);
//    cout<<"Size is : "<<size;
    return 0;
}