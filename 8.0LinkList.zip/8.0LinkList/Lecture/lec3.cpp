#include<iostream>
using namespace std;

class Node{
    public:
    int Data;
    Node *Next;
    Node(int Data){
        this->Data = Data;
        this->Next = NULL;
    } 
};

Node *Takeinput(){
    int Data;
    cin>>Data;
    Node * head = NULL;           // two block create head store the address of Null 
    Node * tail = NULL;
    while (Data != -1)
    {
     Node *newNode = new Node(Data);   
     if(head==NULL){
        head= newNode;  // cause it store the address of newNode  and newNode is also a pointer that why we wrote this
        tail = newNode;
     }else{
        tail->Next = newNode;
        tail = tail->Next;
     }
     cin>>Data;
    }
    return head;
} 

void print(Node * head){
    Node * temp = head;
    while (temp !=NULL)
    {
        cout<<temp->Data<<" ";
        temp= temp->Next;
    }    
}

int main(){
    Node * head = Takeinput();
    print(head);
    return 0;
}