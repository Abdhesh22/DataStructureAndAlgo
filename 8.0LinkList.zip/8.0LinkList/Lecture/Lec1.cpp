#include<bits/stdc++.h>
using namespace std;

class Node{
    public:
    int Data;
    Node *Next;
    Node(int Data){
        this->Data =Data;
        this->Next = NULL;
    }
};

int main(){
    Node N1(1);
    Node N2(2);
    // lets connect both nodes using next ;  N1->Address of N2 
    N1.Next =&N2; //Here we connect it successfully.
    //now we have to connect N1 to the head because if we can't do that then we are not able to find the address of n1;
    //first create a pointer named head for storing the address of n1.
    Node *Head;//here we create it successfully.
    Head = &N1; //here connect it successfully. lets print the data of n1 using head and n1 to.
    cout<<N1.Data<<" "<<Head->Data;
    //Dynamically.
    return 0;
}