#include<iostream>
using namespace std;

class Node{
    public:
        int data;
        Node * Next;
        Node(int data){
            this->data = data;
            this->Next =NULL;
    }
};

Node * takeinput(){
    int data;
    cin>>data;
    Node * head = NULL;
    Node * tail = NULL;
    while(data != -1){
        Node *newNode  = new Node(data);
        if(head == NULL){
            head = newNode;
            tail = newNode;
        }else{
            tail->Next = newNode;
            tail = tail->Next;
        }
        cin>>data;
    }
    return head;
}

void print(Node * head){
    Node * temp = head;
    while (temp != NULL)
    {
        cout<<temp->data<<" ";
        temp = temp->Next;
    }
    cout<<endl;
}

int FindNode(Node * head,int Data){
    int count = 0;
    Node * temp = head;
    while (temp != NULL)
    {
        if (temp->data == Data)
        {
            return count;
        }
        count++;
        temp = temp->Next;
    }
    return -1;
}

Node * FirstNNode(Node * head,int i){
    Node * temp = head;
    int count =1;
    while (temp!=NULL && count < i -1)
    {
        temp = temp->Next;
        count++;
    }
    Node * a = temp->Next;
    Node * b = a->Next;
    temp->Next = b;
    Node * ptr =head ;
    head = a;
    a->Next = ptr;
    return head;
}

int main(){
    Node *head = takeinput();
    print(head); 
    // int data;
    // cin>>data;  
    // int index = FindNode(head,data);
    // cout<<index;
    int index;
    cin>>index;
    head = FirstNNode(head,index);
    print(head);
    return 0;
}