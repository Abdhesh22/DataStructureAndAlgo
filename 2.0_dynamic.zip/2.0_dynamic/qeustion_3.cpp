#include<iostream>
using namespace std;

int func(int i, int &j, int &p){   // note here we take j as reference so change in j apply on whole program. while change in i,p only for this function(note: for making changes in i,p you have to pass i,p as reference).
    i++;
    j++;//pass by reference
    p++;
}

int main(){
    int i = 10;
    int j = 6;
    int p=i;
    func(i,j,p);
    cout << i<<" "<<j<<" " <<p; 
    return 0;
}