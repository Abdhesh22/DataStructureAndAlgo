#include<iostream>
using namespace std;
// -----------------------------typecasting question
void update(int *p){
    *p = 610 % 255;        //now here p store  100as integer (note it is only for  function).
}
int main(){
    char ch = 'A';  //implicit typecasting
    update((int *)&ch);   //now ch become an interger address(only for function)   this is explicit typecasting
    cout << ch; //here ch is behave  like a character   ch = 100 and d 's ascii value is 100.
    return 0;
}
