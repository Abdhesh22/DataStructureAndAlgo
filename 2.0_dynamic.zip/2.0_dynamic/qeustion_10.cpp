#include<iostream>
using namespace std;
#define SQUARE(x)  x*x;

int main(){
 
    int x=36 / SQUARE(6);
    // int y = 5 / SQUARE(5);

    cout<<x;
    return 0;
}